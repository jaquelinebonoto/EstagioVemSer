package eleicoes.recursos;

/**
 *
 * @author 0783170
 */
public enum Situacao {
    FECHADA, ABERTA, ENCERRADA
}
